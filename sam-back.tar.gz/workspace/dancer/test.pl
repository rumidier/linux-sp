#!/usr/bin/env perl 

use strict;
use warnings;
use Dancer;

=pod
any ['get', 'post']=> '/login'=> sub {
    my $err;

    if ( request->method() eq "POST" ) {
        if (params->{'username'} ne setting('username')) {
            $err = "Invalid username";
        }
        elsif ( params->{'password'} ne setting('password')) {
            $err = "Invalid password";
        }
        else {
            session 'logged_in' => true;
            set_flash('You are logged in.');
            return redirect '/';
        }
    }

    template 'login.tt', {
        'err' => $err,
    };
};
=cut

get '/' => sub {
    send_file 'index.html';
};

start;
