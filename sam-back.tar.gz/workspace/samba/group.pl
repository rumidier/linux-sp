#!/usr/bin/env perl 

use 5.010;
use strict;
use warnings;
use Unix::GroupFile;

my $grp = Unix::GroupFile->new('/etc/group');

=pod
foreach my $count ( 1 .. 5 ) {
    print "rumidier0$count\n";
#$grp->delete("rumidier0$count");
    $grp->group("rumidier0$count", "*", $grp->maxgid + 1);
    $grp->commit;
    $grp->passwd("rumidier0$count", $grp->encpass("rumidier0$count"));
    $grp->commit;
}
=cut
    $grp->group("av", "*", $grp->maxgid + 1);
    $grp->commit;
    $grp->group("bv", "*", $grp->maxgid + 1);
    $grp->commit;
    $grp->group("cv", "*", $grp->maxgid + 1);
    $grp->commit;
    $grp->group("dv", "*", $grp->maxgid + 1);
    $grp->commit;
    $grp->group("av_cath", "*", $grp->maxgid + 1);
    $grp->commit;
    $grp->group("bv_cath", "*", $grp->maxgid + 1);
    $grp->commit;
    $grp->group("cv_cath", "*", $grp->maxgid + 1);
    $grp->commit;
    $grp->group("dv_cath", "*", $grp->maxgid + 1);
    $grp->commit;

undef $grp;
