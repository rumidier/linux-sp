#!/usr/bin/env perl 

use 5.010;
use strict;
use warnings;
use Unix::PasswdFile;

my $pw = Unix::PasswdFile->new('/etc/passwd');
my $id = $pw->maxuid + 1;
$pw->user("N111623", '*', $id, $id,
        "서희원", "/home/N111623", "/sbin/nologin");
$pw->commit;
undef $pw;
