#!/usr/bin/env perl
package mywebapp;
use 5.014;
use Template;
use Dancer ':syntax';
use Passwd::Samba;
use Unix::PasswdFile;

our $VERSION = '0.1';

get '/hello/:name' => sub {
    my $name = params->{name};
    template 'hello', { name => $name };
};

get '/gksdud' => sub {
    template 'gksdud';
};

get '/' => sub {
    template 'index';
};

any '/test' => sub {
    template 'test';
};

get '/select' => sub {
    template 'select', {
        u_add => '/u_add',
        u_del => '/u_del',
    };
};

post '/u_del' => sub {
    template 'u_del', {
        action   => '/del_test',
    } ;
};

post '/u_add' => sub {
    template 'u_add', {
        action   => '/add_test',
    } ;
};

post '/del_test' => sub {
    my $id       = param('ID');
    my $n_nick   = param('nick_n');
    my $pw = Unix::PasswdFile->new('/etc/passwd');

    $pw->delete("$id");
    $pw->commit;
    undef $pw;

    template 'u_del', {
        action   => '/u_del',
        id       => $id,
        nick_n   => $n_nick,
    };
};

post '/add_test' => sub {
    my $id       = param('ID');
    my $password = param('password');
    my $n_nick   = param('nick_n');
    my $group    = param('group');
    my $a_group  = param('another_group');

    my $pw = Unix::PasswdFile->new('/etc/passwd');
    my $u_id = $pw->maxuid + 1;
    $pw->user($id, '*', $u_id, $u_id, $id, "/home/$id",
            "/sbin/nologin");
    $pw->commit;
    undef $pw;

    template 'u_add', {
        action   => '/u_add',
        id       => $id,
        password => $password,
        nick_n   => $n_nick,
        group    => $group,
        a_group  => $a_group,
    };
};

post '/sum' => sub {
    "I say a number:".params->{number};
};

get '/add' => sub {
    template 'test', {
        action => '/add',
        num1   => 0,
        num2   => 0,
        sum    => 0,
    };
};

post '/add' => sub {
    my $num1 = param('num-1') || 0;
    my $num2 = param('num-2') || 0;
    template 'test', {
        action  => '/add',
        num1    => $num1,
        num2    => $num2,
#        sum     => $num1 + $num2,
    };
};

true;
